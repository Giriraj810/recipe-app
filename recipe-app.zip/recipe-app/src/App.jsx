
import "./App.css";
import Recipes from "./Pages/Recipe";


function App() {
  return (
    <div className="App">
      <Recipes/>
   
    </div>
  );
}

export default App;
